class Animal:
    def eat(self):
        return "eating..."
#
# cat = Animal()
# print(cat.eat())
