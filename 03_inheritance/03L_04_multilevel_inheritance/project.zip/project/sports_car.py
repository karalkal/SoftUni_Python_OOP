from project.car import Car

class SportsCar(Car):
    def race(self):
        return "racing..."

alfa_romeo = SportsCar()
print(alfa_romeo.race())
print(alfa_romeo.drive())
print(alfa_romeo.move())